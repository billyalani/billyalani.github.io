import pygame

class Player():
	def __init__(self,x,y,height,width,color):
		self.x = x
		self.y = y
		self.x1 = x
		self.y1 = y
		self.x2 = self.x + width
		self.y2 = self.y + height
		self.height = height
		self.width = width
		self.color = color
		self.velocity = 10
		self.jumping = False
		self.velocity_index = 0
		self.collided = False

	def itRight(self,target):
		if self.x2 <= target.x1:
			return True
		return False

	def itUp(self,target):
		if self.y2 <= target.y1:
			return True
		return False

	def itDown(self,target):
		if self.y2 >= target.y1:
			return True
		return False

	def coords(self):
		return (self.x1,self.y1,self.x2,self.y2)

	def hasCollided(self,target):
		tx1,ty1,tx2,ty2 = target.coords()
		if tx1 > self.x2 or tx2 < self.x1 or ty1 > self.y2 or ty2 < self.y1:
			return False
		return True

	def spawn(self,win):
		pygame.draw.rect(win,self.color,(self.x,self.y,self.height,self.width))


	def moveUp(self):
		self.y -= self.velocity
	def moveDown(self):
		self.y += self.velocity
	def moveRight(self):
		self.x += self.velocity
	def moveLeft(self):
		self.x -= self.velocity

	def update(self):
		self.x1 = self.x
		self.y1 = self.y
		self.x2 = self.x + self.width
		self.y2 = self.y + self.height