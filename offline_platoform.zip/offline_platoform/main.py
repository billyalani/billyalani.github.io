import pygame
from player import *
from plat import *

pygame.init()
CLOCK = pygame.time.Clock()
FPS = 60

win = pygame.display.set_mode((900,600))
pygame.display.set_caption("Main")


my_player = Player(100,100,100,100,(255,0,0))

platform = Platform(300,250,200,20,(0,255,100))

run = True

while run:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			run = False

	keys = pygame.key.get_pressed()

	if my_player.hasCollided(platform):
		my_player.collided = True
	else:
		my_player.collided = False

	if keys[pygame.K_d] and (not my_player.itRight(platform) or my_player.itRight(platform) and not my_player.collided):
		my_player.moveRight()

	if keys[pygame.K_a]: #and (not my_player.collided or my_player.itRight(platform) and my_player.collided):
		my_player.moveLeft()

	if keys[pygame.K_s] and (not my_player.itUp(platform) or my_player.itUp(platform) and not my_player.collided):
		my_player.moveDown()

	if keys[pygame.K_w] and (not my_player.itDown(platform) or my_player.itDown(platform) and not my_player.collided):
		my_player.moveUp()


	win.fill((255,255,255))

	my_player.spawn(win)

	platform.spawn(win)

	if my_player.hasCollided(platform):
		platform.color = (0,0,0)
	else:
		platform.color = (0,255,100)


	my_player.update()

	pygame.display.update()
	CLOCK.tick(FPS)