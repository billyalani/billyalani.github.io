import pygame

class Platform():
	def __init__(self,x,y,height,width,color):
		self.x = x
		self.y = y
		self.x1 = x
		self.y1 = y
		self.x2 = self.x + height
		self.y2 = self.y + width
		self.height = height
		self.width = width
		self.color = color

	def coords(self):
		return (self.x1,self.y1,self.x2,self.y2)

	def hasCollided(self,target):
		tx1,ty1,tx2,ty2 = target.coords()
		if tx1 > self.x2 or tx2 < self.x1 or ty1 > self.y2 or ty2 < self.y1:
			return False
		return True

	def spawn(self,win):
		pygame.draw.rect(win,self.color,(self.x,self.y,self.height,self.width))